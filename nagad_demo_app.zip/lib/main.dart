// main.dart
// Nagad-style Demo Receipt App (Flutter single-file example)
// PURPOSE: UI demo only. All outputs are clearly marked SAMPLE / NOT REAL.
// Tested with Flutter stable (>=2.10). Requires image_picker plugin.

import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

void main() => runApp(NagadDemoApp());

class NagadDemoApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Nagad Demo Receipt',
      theme: ThemeData(
        primarySwatch: Colors.red,
        fontFamily: 'Roboto',
      ),
      home: DemoHomePage(),
    );
  }
}

class DemoHomePage extends StatefulWidget {
  @override
  _DemoHomePageState createState() => _DemoHomePageState();
}

class _DemoHomePageState extends State<DemoHomePage> {
  File? _imageFile;
  final ImagePicker _picker = ImagePicker();

  // Default demo values
  String amount = '৳ 3,500.00';
  String fromNo = '+8801633574070';
  String toNo = '+8801YYYYYYYY';
  String dateStr = 'Sep. 25, 05:44 AM';
  String trxId = '74E9PT06';
  String agent = 'Demo Agent - Dhaka';

  Future<void> _pickImage() async {
    final XFile? picked = await _picker.pickImage(source: ImageSource.gallery, maxWidth: 1440);
    if (picked != null) {
      setState(() {
        _imageFile = File(picked.path);
      });
    }
  }

  void _resetImage() {
    setState(() {
      _imageFile = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Nagad Demo (SAMPLE)'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: [
                SizedBox(height: 8),
                _buildControls(),
                SizedBox(height: 12),
                _buildMockupCard(context),
                SizedBox(height: 24),
                Text('App is for DEMO / DESIGN purposes only. NOT A REAL TRANSACTION.',
                    style: TextStyle(color: Colors.grey[700])),
                SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildControls() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        ElevatedButton.icon(
          onPressed: _pickImage,
          icon: Icon(Icons.photo),
          label: Text('Pick App Image'),
          style: ElevatedButton.styleFrom(primary: Colors.red),
        ),
        SizedBox(width: 12),
        OutlinedButton.icon(
          onPressed: _resetImage,
          icon: Icon(Icons.refresh),
          label: Text('Reset'),
        ),
      ],
    );
  }

  Widget _buildMockupCard(BuildContext context) {
    final double cardWidth = MediaQuery.of(context).size.width * 0.95;
    return Stack(
      children: [
        Container(
          width: cardWidth,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(18),
            boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 12, offset: Offset(0,6))],
          ),
          child: Column(
            children: [
              // Header area (mimic app header)
              Container(
                width: double.infinity,
                padding: EdgeInsets.symmetric(vertical: 18, horizontal: 18),
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [Colors.red.shade400, Colors.red.shade200]),
                  borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.account_balance_wallet, color: Colors.white, size: 28),
                    SizedBox(width: 10),
                    Text('ক্যাশ আউট', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w700)),
                  ],
                ),
              ),

              // Screenshot area (user image or placeholder)
              Container(
                height: 420,
                color: Colors.grey[100],
                child: _imageFile != null
                    ? ClipRRect(borderRadius: BorderRadius.zero, child: Image.file(_imageFile!, fit: BoxFit.cover, width: double.infinity))
                    : _placeholderScreenshot(),
              ),

              // Amount and details
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 18.0, vertical: 16),
                child: Column(
                  children: [
                    Text(amount, style: TextStyle(fontSize: 46, fontWeight: FontWeight.w900, color: Colors.black87)),
                    SizedBox(height: 6),
                    Text('CASH OUT — COMPLETED (SAMPLE)', style: TextStyle(color: Colors.grey[700], fontSize: 14)),

                    SizedBox(height: 18),
                    _buildDetailRow('অ্যাকাউন্ট নং', fromNo),
                    SizedBox(height: 8),
                    _buildDetailRow('পরিমাণ', amount),
                    SizedBox(height: 8),
                    _buildDetailRow('ট্রানজেকশন আইডি', trxId),
                    SizedBox(height: 8),
                    _buildDetailRow('দিন ও সময়', dateStr),
                    SizedBox(height: 8),
                    _buildDetailRow('এজেন্ট', agent),
                  ],
                ),
              ),

              SizedBox(height: 12),
            ],
          ),
        ),

        // large diagonal watermark
        Positioned.fill(
          child: IgnorePointer(
            child: Center(
              child: Transform.rotate(
                angle: -0.35,
                child: Opacity(
                  opacity: 0.12,
                  child: Text('SAMPLE — NOT REAL — FOR DEMO',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 36, fontWeight: FontWeight.w900, color: Colors.red)),
                ),
              ),
            ),
          ),
        ),

        // small demo badge
        Positioned(
          top: 12,
          right: 12,
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(color: Colors.white70, borderRadius: BorderRadius.circular(12)),
            child: Text('DEMO', style: TextStyle(color: Colors.red[700], fontWeight: FontWeight.bold)),
          ),
        ),
      ],
    );
  }

  Widget _placeholderScreenshot() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.smartphone, size: 56, color: Colors.grey[400]),
            SizedBox(height: 12),
            Text('No app screenshot provided', style: TextStyle(color: Colors.grey[600], fontSize: 16)),
            SizedBox(height: 6),
            Text('Use "Pick App Image" to embed a real screenshot (for demo only).', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[500])),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailRow(String key, String value) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(width: 8),
        Expanded(flex: 3, child: Text(key, style: TextStyle(color: Colors.grey[700], fontSize: 14))),
        Expanded(flex: 5, child: Text(value, style: TextStyle(color: Colors.black87, fontSize: 15, fontWeight: FontWeight.w600))),
        SizedBox(width: 8),
      ],
    );
  }
}

/*
Instructions:
1) Create a new Flutter project and replace lib/main.dart with this file.
2) Add dependency in pubspec.yaml:
   image_picker: ^0.8.7
3) For Android manifest, add required permissions (READ_EXTERNAL_STORAGE / CAMERA as needed).
4) Run 'flutter pub get' then 'flutter run' on a connected device.

Remember: This app is for demo/design only. Do not use generated images to deceive.
